import Stripe from "stripe"

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2025-02-24.acacia" as any, // Cast to any to prevent compile errors if the SDK has different types, or use latest standard
  typescript: true,
})
