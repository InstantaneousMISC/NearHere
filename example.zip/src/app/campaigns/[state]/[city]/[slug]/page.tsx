import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { createCaller } from '@/lib/trpc/server'
import { CampaignNav } from '@/components/campaign/CampaignNav'
import CampaignHero from '@/components/campaign/CampaignHero'
import ValueProps from '@/components/campaign/ValueProps'
import CampaignStats from '@/components/campaign/CampaignStats'
import InteractivePostcardArea from '@/components/campaign/InteractivePostcardArea'
import HowItWorks from '@/components/campaign/HowItWorks'
import FAQ from '@/components/campaign/FAQ'
import CampaignFooter from '@/components/campaign/CampaignFooter'

export async function generateMetadata({
  params,
}: {
  params: Promise<{ state: string; city: string; slug: string }>
}): Promise<Metadata> {
  const { city, state } = await params
  const cityName = city.charAt(0).toUpperCase() + city.slice(1)
  const stateName = state.charAt(0).toUpperCase() + state.slice(1)
  return {
    title: `NearHere ${cityName}, ${stateName} Shared Postcard Campaign`,
    description: `Reserve a featured placement in the ${cityName} NearHere shared postcard campaign with a unique QR destination and managed mailing.`,
  }
}

export default async function CampaignPage({
  params,
}: {
  params: Promise<{ state: string; city: string; slug: string }>
}) {
  const { state, city, slug } = await params
  
  const caller = await createCaller()
  const campaign = await caller.campaign.getByLocation({ state, city, slug })

  if (!campaign) {
    return notFound()
  }

  const cityName = campaign.city.charAt(0).toUpperCase() + campaign.city.slice(1)
  const stateName = campaign.state.charAt(0).toUpperCase() + campaign.state.slice(1)
  const mailingQuantity = campaign.mailingQuantity

  return (
    <main className="min-h-screen bg-paper text-press">
      {/* Announcement Bar */}
      <div className="bg-press text-paper">
        <div className="max-w-7xl mx-auto px-6 py-2 flex flex-wrap items-center justify-between gap-2">
          <p className="font-mono uppercase tracking-[0.14em] text-[10px] text-paper/80">
            Now Reserving / {cityName}, {stateName} Campaign / Planned for 2026
          </p>
          <p className="font-mono uppercase tracking-[0.14em] text-[10px] text-gold">
            Limited Placements / Category Rules Apply
          </p>
        </div>
      </div>

      <CampaignNav state={state} city={city} slug={slug} />

      <CampaignHero
        name={campaign.name}
        city={campaign.city}
        state={campaign.state}
        mailingQuantity={campaign.mailingQuantity}
        spots={campaign.spots}
      />

      {/* Active Campaign Info Header Card */}
      <section className="bg-muted/40 border-b border-rule" id="campaign">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="border border-press bg-paper">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-press px-8 py-5">
              <h3 className="headline-xl text-2xl md:text-3xl text-press">{cityName} NearHere Campaign</h3>
              <div className="flex gap-2">
                <span className="inline-flex items-center font-mono text-[10px] uppercase tracking-[0.14em] px-2 py-1 border border-gold text-gold bg-transparent">
                  Premium Shared Postcard
                </span>
                <span className="inline-flex items-center font-mono text-[10px] uppercase tracking-[0.14em] px-2 py-1 border border-press text-press bg-transparent">
                  Local Campaign
                </span>
              </div>
            </div>
            <div className="grid md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-rule">
              {[
                ["Target Area", `${cityName}, ${stateName}`],
                ["Estimated Distribution", `${mailingQuantity.toLocaleString()} nearby households`],
                ["Format", "Premium 9x12 shared postcard"],
                ["Tracking", "Unique advertiser QR destination"],
                ["Availability", "Limited campaign placements"],
                ["Production", "Layout, print, and mailing coordinated"],
              ].map(([k, v]) => (
                <div key={k} className="px-8 py-6">
                  <p className="label-mono">{k}</p>
                  <p className="mt-2 font-headline font-bold text-xl text-press">{v}</p>
                </div>
              ))}
            </div>
            <div className="border-t border-press px-8 py-5 flex flex-wrap justify-between items-center gap-3 bg-paper">
              <p className="label-mono">Limited positions left • Reservations close soon</p>
              <a href="#categories" className="bg-transparent border border-press text-press px-5 py-2 font-headline font-bold uppercase tracking-wider text-xs hover:bg-press hover:text-paper transition-colors rounded-none">
                View Available Placements
              </a>
            </div>
          </div>
        </div>
      </section>

      <ValueProps
        city={campaign.city}
        state={campaign.state}
      />

      {/* For Businesses / Residents */}
      <section className="border-t border-rule bg-paper text-press">
        <div className="max-w-7xl mx-auto px-6 py-20 grid md:grid-cols-2 gap-0 border-x border-rule">
          <div className="p-10 border-r border-rule flex flex-col justify-between items-start bg-paper">
            <div>
              <span className="inline-flex items-center font-mono text-[10px] uppercase tracking-[0.14em] px-2 py-1 border border-gold text-gold bg-transparent">
                For Local Businesses
              </span>
              <h3 className="headline-xl text-3xl md:text-4xl mt-6 text-press">Build visibility in nearby neighborhoods.</h3>
              <p className="mt-5 text-press/75 leading-relaxed text-sm">
                Your campaign placement also includes a public NearHere Business Profile with your business description, local offer, contact details, service area, and website link. This gives postcard recipients a simple place to learn more after scanning your QR code and gives your business another local online presence.
              </p>
            </div>
            <div className="mt-8">
              <a href="#categories" className="bg-nh-red text-paper px-6 py-3 font-headline font-bold uppercase tracking-wider text-sm hover:bg-press transition-colors rounded-none">
                Reserve a Spot
              </a>
            </div>
          </div>
          <div className="p-10 bg-press text-paper flex flex-col justify-between items-start">
            <div>
              <span className="inline-flex items-center font-mono text-[10px] uppercase tracking-[0.14em] px-2 py-1 border border-paper/40 text-paper/85">
                For Residents
              </span>
              <h3 className="headline-xl text-3xl md:text-4xl mt-6 text-paper">Useful local options in one place.</h3>
              <p className="mt-5 text-paper/75 leading-relaxed text-sm">
                NearHere postcards organize nearby services and offers with clear ways to call,
                scan, visit a website, or mention the card.
              </p>
            </div>
            <div className="mt-8">
              <a href="#preview" className="bg-paper text-press px-6 py-3 font-headline font-bold uppercase tracking-wider text-sm hover:bg-nh-red hover:text-paper transition-colors rounded-none">
                Preview the Postcard
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Why It Works */}
      <section className="border-t border-rule bg-press text-paper border-press">
        <div className="max-w-7xl mx-auto px-6 py-20">
          <p className="font-mono uppercase tracking-[0.14em] text-[11px] text-paper/60">Why It Works</p>
          <h2 className="headline-xl text-4xl md:text-5xl mt-4 max-w-3xl text-paper">A better way to show up in the mailbox.</h2>
          <div className="mt-12 grid md:grid-cols-3 gap-px bg-paper/10 border border-paper/10">
            {[
              ["Curated, not cluttered", "A clean editorial postcard format — never junk mail."],
              ["Neighborhood distribution", `Planned for households in the target ${cityName} campaign area.`],
              ["Limited inventory", "Campaign placement and category availability are shown before checkout."],
              ["Multiple response paths", "Residents can call, scan, visit a website, or mention the postcard."],
              ["Managed production", "NearHere coordinates layout, print preparation, and mailing logistics."],
              ["QR included", "Each advertiser receives a unique digital destination for basic scan reporting."],
            ].map(([t, d]) => (
              <div key={t} className="bg-press p-8 text-left">
                <h4 className="font-headline font-bold uppercase tracking-wide text-lg text-paper">{t}</h4>
                <p className="mt-3 text-paper/70 leading-relaxed text-sm">{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CampaignStats
        spots={campaign.spots}
        mailingQuantity={campaign.mailingQuantity}
        city={campaign.city}
      />

      {/* Testimonial */}
      <section className="border-t border-rule bg-paper text-press">
        <div className="max-w-5xl mx-auto px-6 py-24 text-center">
          <p className="label-mono">Campaign Design Principle</p>
          <blockquote className="headline-xl text-3xl md:text-5xl mt-8 leading-[1.05] text-press">
            Clear local visibility, useful response paths, and campaign reporting without
            overpromising outcomes.
          </blockquote>
          <div className="mt-8 inline-flex flex-col items-center">
            <p className="font-headline font-bold text-lg text-press">NearHere Campaign Standard</p>
            <p className="label-mono mt-1">Rivera & Sons Plumbing • {cityName}, {stateName}</p>
          </div>
        </div>
      </section>
      
      <InteractivePostcardArea
        spots={campaign.spots as any}
        state={state}
        city={city}
        slug={slug}
        campaignId={campaign.id}
        zipCode={campaign.zipCode || ""}
        cardSize={campaign.cardSize}
        cardSkin={campaign.cardSkin}
        mailingQuantity={campaign.mailingQuantity}
      />

      {/* Digital Companion */}
      <section className="border-t border-rule bg-paper text-press">
        <div className="max-w-7xl mx-auto px-6 py-20 grid md:grid-cols-12 gap-8 border-x border-rule">
          <div className="md:col-span-5 flex flex-col justify-center text-left">
            <p className="label-mono">Advertiser QR Destination</p>
            <h2 className="headline-xl text-4xl md:text-5xl mt-4 font-bold text-press">Physical visibility with a digital response path.</h2>
          </div>
          <div className="md:col-span-7 flex flex-col items-start justify-center text-left">
            <p className="text-lg text-press/75 leading-relaxed">
              Your campaign placement also includes a public NearHere Business Profile with your business description, local offer, contact details, service area, and website link. This gives postcard recipients a simple place to learn more after scanning your QR code and gives your business another local online presence.
            </p>
            <div className="mt-8">
              <a
                href="#preview"
                className="inline-flex items-center justify-center border border-press text-press px-6 py-3 font-headline font-bold uppercase tracking-wider text-sm hover:bg-press hover:text-paper transition-colors rounded-none"
              >
                Preview Local Page
              </a>
            </div>
          </div>
        </div>
      </section>

      <HowItWorks
        city={campaign.city}
        state={campaign.state}
      />
      <FAQ
        city={campaign.city}
        state={campaign.state}
        mailingQuantity={campaign.mailingQuantity}
      />
      <CampaignFooter />
    </main>
  )
}
