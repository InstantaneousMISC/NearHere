"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import SharedCard9x12 from "./SharedCard9x12"
import CommunityCard6x11 from "./CommunityCard6x11"

interface PostcardSpot {
  id: string
  label: string
  side: "FRONT" | "BACK"
  spotType: "PREMIUM" | "LARGE" | "STANDARD" | "SMALL"
  price: number // cents
  x: number
  y: number
  width: number
  height: number
  status: "OPEN" | "HELD" | "SOLD" | "UNAVAILABLE"
  categoryId: string
  category: {
    id: string
    name: string
  }
}

interface PostcardPreviewProps {
  spots: PostcardSpot[]
  state: string
  city: string
  slug: string
  onWaitlistClick: (category: { id: string; name: string }) => void
  cardSize?: string
  cardSkin?: string
}

export default function PostcardPreview({
  spots,
  state,
  city,
  slug,
  onWaitlistClick,
  cardSize = "9x12",
  cardSkin = "cream"
}: PostcardPreviewProps) {
  const router = useRouter()
  const [activeSide, setActiveSide] = useState<"FRONT" | "BACK">("FRONT")

  const cityName = city.charAt(0).toUpperCase() + city.slice(1)
  const stateName = state.charAt(0).toUpperCase() + state.slice(1)

  // Extract mailing quantity if available
  const campaignRecord = spots.length > 0 ? (spots[0] as any).campaign : null
  const quantity = campaignRecord?.mailingQuantity ?? 10000
  const homesCount = `${new Intl.NumberFormat().format(quantity)} HOMES`

  const handleSpotClick = (spot: PostcardSpot) => {
    if (spot.status === "SOLD") {
      onWaitlistClick({ id: spot.category.id, name: spot.category.name })
    } else if (spot.status === "OPEN" || spot.status === "HELD") {
      router.push(`/campaigns/${state.toLowerCase()}/${city.toLowerCase()}/${slug.toLowerCase()}/checkout/${spot.id}`)
    }
  }

  return (
    <div id="preview" className="w-full max-w-4xl mx-auto space-y-6">
      {/* Side Selector Tabs */}
      <div className="flex justify-center">
        <div className="border border-press bg-paper p-1 flex gap-1 font-mono text-[10px] uppercase tracking-wider font-bold">
          <button
            type="button"
            onClick={() => setActiveSide("FRONT")}
            className={`px-5 py-2 transition-all cursor-pointer rounded-none ${
              activeSide === "FRONT"
                ? "bg-press text-paper"
                : "text-warm hover:text-press bg-transparent"
            }`}
          >
            Front Side (Premium)
          </button>
          <button
            type="button"
            onClick={() => setActiveSide("BACK")}
            className={`px-5 py-2 transition-all cursor-pointer rounded-none ${
              activeSide === "BACK"
                ? "bg-press text-paper"
                : "text-warm hover:text-press bg-transparent"
            }`}
          >
            Back Side (Mailing & Standard)
          </button>
        </div>
      </div>

      {/* aspect ratio postcard view wrapper with horizontal scroll for mobile screens */}
      <div className="w-full overflow-x-auto pb-4 md:overflow-x-visible">
        <div className="min-w-[700px] md:min-w-0">
          {cardSize === "6x11" ? (
            <CommunityCard6x11
              view={activeSide === "FRONT" ? "front" : "back"}
              locationLabel={`${cityName.toUpperCase()}, ${stateName.toUpperCase()}`}
              homesCount={homesCount}
              spots={spots}
              onSpotClick={handleSpotClick}
              cardSkin={cardSkin}
            />
          ) : (
            <SharedCard9x12
              view={activeSide === "FRONT" ? "front" : "back"}
              locationLabel={`${cityName.toUpperCase()}, ${stateName.toUpperCase()}`}
              homesCount={homesCount}
              spots={spots}
              onSpotClick={handleSpotClick}
              cardSkin={cardSkin}
            />
          )}
        </div>
      </div>
    </div>
  )
}
