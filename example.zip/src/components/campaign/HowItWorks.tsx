interface HowItWorksProps {
  city?: string
  state?: string
}

export default function HowItWorks({ city = "" }: HowItWorksProps) {
  const cityName = city ? city.charAt(0).toUpperCase() + city.slice(1) : "your area"

  const steps = [
    {
      num: "01",
      title: "Choose a Placement",
      desc: "Review the live postcard preview and select an available front, back, double, or premium campaign placement.",
    },
    {
      num: "02",
      title: "Select Your Category",
      desc: "Search available business categories before checkout. Category exclusivity applies only where campaign rules provide it.",
    },
    {
      num: "03",
      title: "Submit Creative Details",
      desc: "Provide your logo, description, offer, phone number, website, and preferred call to action.",
    },
    {
      num: "04",
      title: "Review and Approve",
      desc: "NearHere prepares the layout, reviews campaign requirements, and coordinates revisions before print approval.",
    },
    {
      num: "05",
      title: "Mail and Monitor",
      desc: `The postcard is prepared for the ${cityName} campaign area. Your dashboard shows campaign status and basic QR activity after mailing.`,
    },
  ]

  return (
    <section className="border-t border-rule bg-muted/30">
      <div id="how" className="mx-auto max-w-7xl px-6 py-20">
        <div className="mb-12 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="label-mono">How It Works</p>
            <h2 className="headline-xl mt-4 text-4xl md:text-5xl">
              From reservation to campaign reporting.
            </h2>
          </div>
        </div>
        <div className="grid border border-rule bg-paper md:grid-cols-2 lg:grid-cols-5">
          {steps.map((step, index) => (
            <div
              key={step.num}
              className={`border-b border-rule bg-paper p-8 lg:border-b-0 ${
                index !== steps.length - 1 ? "lg:border-r" : ""
              }`}
            >
              <div className="font-mono text-xs tracking-[0.14em] text-nh-red">STEP {step.num}</div>
              <h3 className="headline-xl mt-4 text-2xl leading-tight text-press">{step.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-press/70">{step.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
