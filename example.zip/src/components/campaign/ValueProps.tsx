interface ValuePropsProps {
  city?: string
  state?: string
}

export default function ValueProps({ city = "" }: ValuePropsProps) {
  const cityName = city ? city.charAt(0).toUpperCase() + city.slice(1) : "local"

  const benefits = [
    {
      title: "Public Business Profile",
      description:
        "Every advertiser receives a public NearHere Business Profile displaying their business description, offer, contact buttons, and website backlink.",
    },
    {
      title: "Website Backlink Included",
      description:
        "Your business profile features a direct link to your website, helping support your broader local online visibility and SEO footprint.",
    },
    {
      title: "Mailed & Scanned Tracking",
      description:
        "A unique campaign QR code points directly to your business profile, allowing scan tracking and basic engagement activity monitoring.",
    },
    {
      title: "Physical Direct Mail",
      description:
        "Get exposure in local household mailboxes using a premium, professionally designed oversized postcard format.",
    },
    {
      title: "Done-For-You Production",
      description:
        "NearHere manages the postcard layout design, print coordination, campaign assembly, and direct mailing logistics.",
    },
    {
      title: "Category Exclusivity",
      description:
        "Placements are limited per campaign. Lock out local competitors with category exclusivity where campaign rules permit.",
    },
  ]

  return (
    <section id="how" className="border-t border-rule bg-paper text-press">
      <div className="mx-auto grid max-w-7xl gap-8 border-x border-rule px-6 py-20 md:grid-cols-12">
        <div className="md:col-span-4">
          <p className="label-mono">What NearHere Is</p>
        </div>
        <div className="md:col-span-8">
          <h2 className="headline-xl text-4xl text-press md:text-5xl">
            A local visibility platform that bundles direct mail with online profiles.
          </h2>
          <p className="mt-6 max-w-2xl text-lg leading-relaxed text-press/75">
            Your placement includes more than postcard exposure. Every advertiser receives a public NearHere Business Profile with their business details, offer, contact information, QR destination, and a link back to their website. This helps customers learn more after scanning the postcard while giving your business another local online presence.
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-7xl border-x border-rule px-6 pb-20">
        <div className="grid gap-px border border-rule bg-rule md:grid-cols-2 lg:grid-cols-3">
          {benefits.map((benefit, index) => (
            <div key={benefit.title} className="bg-paper p-8">
              <div className="font-mono text-xs tracking-[0.14em] text-nh-red">
                BENEFIT {String(index + 1).padStart(2, "0")}
              </div>
              <h3 className="headline-xl mt-4 text-2xl text-press">{benefit.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-press/70">{benefit.description}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="mx-auto max-w-7xl border-x border-rule px-6 pb-20">
        <div className="grid items-center gap-8 border border-press bg-paper p-8 md:grid-cols-12">
          <div className="space-y-4 md:col-span-8">
            <span className="inline-flex border border-nh-red px-2 py-1 font-mono text-[10px] uppercase tracking-[0.14em] text-nh-red mr-2 mb-2 sm:mb-0">
              Advertiser Eligibility and Quality Review
            </span>
            <span className="inline-flex border border-press px-2 py-1 font-mono text-[10px] uppercase tracking-[0.14em] text-press">
              Postcard placement + QR tracking + business profile + website backlink included
            </span>
            <h3 className="headline-xl text-2xl text-press md:text-3xl">
              Clear standards protect campaign quality.
            </h3>
            <p className="text-sm leading-relaxed text-press/75">
              Businesses should actively serve the {cityName} area, provide accurate contact
              information, and comply with applicable licensing and advertising requirements.
              NearHere may review submissions before final print approval.
            </p>
          </div>
          <div className="space-y-3 border border-rule bg-muted/40 p-6 md:col-span-4">
            <h4 className="font-headline font-bold uppercase tracking-wider text-press">
              Review Before Print
            </h4>
            <p className="text-xs leading-relaxed text-press/70">
              A reservation may be canceled if a business or creative submission does not meet
              campaign requirements. Any refund is handled under the applicable advertiser
              agreement and payment terms.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
