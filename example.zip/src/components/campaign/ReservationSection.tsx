"use client"

import type {
  ReservationPlan,
  ReservationSpot,
} from "./ReservationModal"
import { TEMPLATE_1_PRICING } from "@/lib/nearHereSharedCard9x12"

interface ReservationSectionProps {
  cardSize: string
  mailingQuantity: number
  spots: ReservationSpot[]
  onSelect: (plan: ReservationPlan, spot: ReservationSpot | null) => void
}

export default function ReservationSection({
  cardSize,
  mailingQuantity,
  spots,
  onSelect,
}: ReservationSectionProps) {
  const isTemplate1 = cardSize === "9x12"
  const plans: ReservationPlan[] = isTemplate1
    ? [
        {
          key: "front-standard",
          name: "Front Standard",
          price: TEMPLATE_1_PRICING.frontStandard,
          costPerHome: "4.9 cents per home",
          description: "High-visibility 230px x 265px placement on the Premium Grid front.",
        },
        {
          key: "back-standard",
          name: "Back Standard",
          price: TEMPLATE_1_PRICING.backStandard,
          costPerHome: "5.9 cents per home",
          description: "Larger 275px placement above or below the protected mailing area.",
        },
        {
          key: "front-double",
          name: "Front Double",
          price: TEMPLATE_1_PRICING.frontDouble,
          costPerHome: "8.9 cents per home",
          description: "Two adjacent front positions for a wider, higher-impact creative.",
          inquiryOnly: true,
        },
        {
          key: "back-double",
          name: "Back Double",
          price: TEMPLATE_1_PRICING.backDouble,
          costPerHome: "9.9 cents per home",
          description: "Two adjacent back positions in a valid top or bottom row.",
          inquiryOnly: true,
        },
        {
          key: "premium-center",
          name: "Premium Center Back",
          price: TEMPLATE_1_PRICING.premiumCenterBack,
          costPerHome: "14.9 cents per home",
          description: "The largest and highest-value placement beside the mailing panel.",
        },
      ]
    : [
        {
          key: "standard",
          name: "Standard Feature",
          price: 450,
          costPerHome: `${((450 * 100) / mailingQuantity).toFixed(1)} cents per home`,
          description: "A standard Community Card placement with trackable QR response.",
        },
        {
          key: "premium",
          name: "Premium Feature",
          price: 1000,
          costPerHome: `${((1000 * 100) / mailingQuantity).toFixed(1)} cents per home`,
          description: "The largest Community Card placement with priority visibility.",
        },
      ]

  const findSpot = (plan: ReservationPlan) =>
    spots.find((spot) => {
      if (spot.status !== "OPEN" && spot.status !== "HELD") return false
      if (plan.key === "front-standard") {
        return spot.side === "FRONT" && spot.spotType === "STANDARD"
      }
      if (plan.key === "back-standard") {
        return spot.side === "BACK" && spot.spotType === "STANDARD"
      }
      if (plan.key === "premium-center" || plan.key === "premium") {
        return spot.spotType === "PREMIUM"
      }
      if (plan.key === "standard") {
        return spot.spotType === "STANDARD" || spot.spotType === "SMALL"
      }
      return false
    }) || null

  return (
    <section id="categories" className="border-y border-rule bg-paper text-press">
      <div className="mx-auto max-w-7xl px-6 py-20">
        <div className="mx-auto max-w-3xl text-center">
          <p className="label-mono">Reservation</p>
          <h2 className="headline-xl mt-4 text-4xl font-bold md:text-5xl">
            Reserve your category.
          </h2>
          <p className="mt-4 text-sm leading-relaxed text-press/70">
            Choose a campaign placement, then select your business type. Every placement includes ad design, postcard placement, a unique QR code, campaign tracking page, public NearHere Business Profile, website backlink, local offer display, printing, and mailing.
          </p>
        </div>

        <div
          className={`mt-12 grid gap-px border border-rule bg-rule ${
            isTemplate1 ? "md:grid-cols-2 xl:grid-cols-5" : "md:grid-cols-2"
          }`}
        >
          {plans.map((plan) => {
            const spot = findSpot(plan)
            const available = Boolean(spot) && !plan.inquiryOnly
            return (
              <article
                key={plan.key}
                className={`flex min-h-[350px] flex-col justify-between bg-paper p-7 ${
                  plan.key === "premium-center" || plan.key === "premium"
                    ? "bg-muted/40"
                    : ""
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <h3 className="headline-xl text-2xl">{plan.name}</h3>
                    <span
                      className={`font-mono text-[8px] font-bold uppercase tracking-[0.1em] ${
                        available ? "text-emerald-700" : "text-[#C9993E]"
                      }`}
                    >
                      {available ? "Available" : "Request"}
                    </span>
                  </div>
                  <div className="mt-6">
                    <span className="headline-xl text-5xl">
                      ${plan.price.toLocaleString()}
                    </span>
                    <span className="label-mono ml-2">per campaign</span>
                  </div>
                  <p className="mt-3 font-mono text-[9px] font-bold uppercase tracking-[0.08em] text-[#D13F1F]">
                    {plan.costPerHome}
                  </p>
                  <p className="mt-6 text-sm leading-relaxed text-press/70">
                    {plan.description}
                  </p>
                  <ul className="mt-6 space-y-1.5 text-xs text-press/80">
                    <li className="flex items-center gap-1.5">✓ <span>Public NearHere Business Profile</span></li>
                    <li className="flex items-center gap-1.5">✓ <span>Website backlink included</span></li>
                    <li className="flex items-center gap-1.5">✓ <span>Unique QR code</span></li>
                    <li className="flex items-center gap-1.5">✓ <span>Campaign tracking page</span></li>
                    <li className="flex items-center gap-1.5">✓ <span>Local offer display</span></li>
                    <li className="flex items-center gap-1.5">✓ <span>Phone and website CTA</span></li>
                    <li className="flex items-center gap-1.5">✓ <span>Basic scan/activity tracking</span></li>
                    <li className="flex items-center gap-1.5">✓ <span>Postcard ad design</span></li>
                    <li className="flex items-center gap-1.5">✓ <span>Printing and mailing</span></li>
                  </ul>
                </div>
                <button
                  type="button"
                  onClick={() => onSelect(plan, spot)}
                  className={`mt-8 w-full px-5 py-3 font-headline text-sm font-black uppercase tracking-[0.06em] ${
                    plan.key === "premium-center" || plan.key === "premium"
                      ? "bg-[#D13F1F] text-white hover:bg-[#211D1C]"
                      : "border border-[#211D1C] hover:bg-[#211D1C] hover:text-white"
                  }`}
                >
                  {available ? "Choose Business Type" : "Request Placement"}
                </button>
              </article>
            )
          })}
        </div>

        <p className="mt-6 text-center font-mono text-[9px] uppercase tracking-[0.08em] text-[#77706A]">
          Founding advertiser pricing applies to this campaign. Back placements cost more because
          they provide larger creative areas. Food and dining categories may support multiple
          advertisers when campaign settings allow it.
        </p>
      </div>
    </section>
  )
}
